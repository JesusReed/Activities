package com.example.testact2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MostrarDatos extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_datos);
        Bundle datos = getIntent().getExtras();
        final String Nombre = datos.getString("nombre");
        final String Telefono = datos.getString("telefono");
        final String Correo = datos.getString("correo");
        final String Descripcion = datos.getString("descripcion");
        int ResDia = datos.getInt("dia");
        int ResMes = datos.getInt("mes");
        int ResAño = datos.getInt("año");
        final TextView Nombre2=(TextView)findViewById(R.id.Nombre2);
        TextView Telefono2=(TextView)findViewById(R.id.Telefono2);
        TextView Correo2=(TextView)findViewById(R.id.Correo2);
        TextView Descripcion2=(TextView)findViewById(R.id.Descripcion2);
        TextView Fecha2 = (TextView)findViewById(R.id.Fecha2);
        Button Editar=(Button)findViewById(R.id.Editar);
        Nombre2.setText("Nombre: "+Nombre);
        Correo2.setText("Correo: "+Correo);
        Telefono2.setText("Teléfono: "+Telefono);
        Descripcion2.setText("Descripción: "+Descripcion);
        Fecha2.setText("Fecha de nacimiento: "+ResDia+"/"+(ResMes+1)+"/"+ResAño);
        Editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MostrarDatos.this, MainActivity.class);
                Bundle regDatos = getIntent().getExtras();
                final int dia = regDatos.getInt("dia");
                final int mes = regDatos.getInt("mes");
                final int año = regDatos.getInt("año");
                i.putExtra("name", Nombre);
                i.putExtra("tele", Telefono);
                i.putExtra("corre", Correo);
                i.putExtra("desc", Descripcion);
                i.putExtra("dia", dia);
                i.putExtra("mes", mes);
                i.putExtra("año", año);
                startActivity(i);
            }
        });
    }
}