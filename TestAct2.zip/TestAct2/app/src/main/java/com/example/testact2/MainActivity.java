package com.example.testact2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button sig = findViewById(R.id.Siguiente);
        sig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MostrarDatos.class);
                final EditText nom = (EditText) findViewById(R.id.etNombre);
                final EditText tel = (EditText) findViewById(R.id.Telefono1);
                final EditText corr = (EditText) findViewById(R.id.Correo1);
                final EditText des = (EditText) findViewById(R.id.Descripcion1);
                final DatePicker fech = (DatePicker) findViewById(R.id.Fecha1);
                int dia = fech.getDayOfMonth();
                int mes = fech.getMonth();
                int año = fech.getYear();
                i.putExtra("nombre",nom.getText().toString());
                i.putExtra("telefono",tel.getText().toString());
                i.putExtra("correo",corr.getText().toString());
                i.putExtra("descripcion",des.getText().toString());
                i.putExtra("dia", dia);
                i.putExtra("mes", mes);
                i.putExtra("año", año);
                startActivity(i);
            }
        });
    }
    protected void onResume(){
        super.onResume();
        Bundle regDatos = this.getIntent().getExtras();
        if (regDatos != null){
        String nombre=regDatos.getString("name");
        String telefono=regDatos.getString("tele");
        String correo=regDatos.getString("corre");
        String descripcion=regDatos.getString("desc");
        int resDia = regDatos.getInt("dia");
        int resMes = regDatos.getInt("mes");
        int resAño = regDatos.getInt("año");
        EditText nom = (EditText)findViewById(R.id.etNombre);
        EditText tel = (EditText)findViewById(R.id.Telefono1);
        EditText corr = (EditText)findViewById(R.id.Correo1);
        EditText des = (EditText)findViewById(R.id.Descripcion1);
        DatePicker fech = (DatePicker) findViewById(R.id.Fecha1);
        nom.setText(nombre);
        tel.setText(telefono);
        des.setText(descripcion);
        corr.setText(correo);
        fech.updateDate(resAño, resMes, resDia);
        }
    }
}